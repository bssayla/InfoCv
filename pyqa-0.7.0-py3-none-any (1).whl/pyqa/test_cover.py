# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Testing Python source code."""

import argparse
import re
import shlex
import sys
import tempfile
from typing import List, Optional

from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.safe_run import log_exception_and_return


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Add command-line arguments for testing.

    :param subparsers: Subparsers to the main pyqa parser
    :type subparsers: argparse._SubParsersAction
    """
    parser_test = subparsers.add_parser("test", help="run tests")
    parser_test.add_argument(
        "paths",
        nargs="+",
        help="paths to test directories",
    )
    parser_test.add_argument("--coverage", help="module name to cover", dest="module_to_cover")

    parser_test.add_argument(
        "--output-dir", help="generate html report in directory", dest="html_report_directory"
    )
    parser_test.add_argument(
        "--parallel",
        type=str,
        help="To run test in parallel with specified number parallel jobs,"
        'or match CPU count if value is "auto" ',
        dest="pytest_parallel",
    )
    parser_test.add_argument(
        "--pytest-args", type=str, help="Handle pytest arguments", dest="pytest_arguments"
    )

    parser_test.set_defaults(run_subcommand=run)


@log_exception_and_return(1)
def run(args: argparse.Namespace) -> int:
    """
    Run tests.

    :param args: Parsed arguments from the ArgumentParser, including `paths`,\
    `html_report_directory` and `pytest_arguments`
    :type args: argparse.Namespace

    :return: Exit code
    :rtype: int
    """

    # Only perform import if this function is called
    import subprocess  # nosec

    print("Running pytest...")

    pytest_args = [sys.executable, "-m", "pytest"]
    if args.module_to_cover:
        pytest_args.append("--cov=" + args.module_to_cover)

        if args.html_report_directory:
            pytest_args.append("--cov-report")
            pytest_args.append(f"html:{args.html_report_directory}/pytest-cov")

    if args.html_report_directory:
        pytest_args.append(f"--html={args.html_report_directory}/pytest/index.html")

    if args.pytest_arguments:
        pytest_arg = shlex.split(args.pytest_arguments)
        for arg in pytest_arg:
            pytest_args.append(arg)

    if args.verbose:
        pytest_args.append("--verbose")

    if args.pytest_parallel:
        pytest_args.append("-n")
        pytest_args.append(args.pytest_parallel)

    for path in args.paths:
        pytest_args.append(path)

    # The use of subprocess here is for running pytest in a new process,
    # because running it in the same process makes the test coverage miss
    # the pre-defined functions and modules, making the coverage results incorrect
    return subprocess.run(pytest_args).returncode  # nosec


@log_exception_and_return(
    [ReportEntry(name="testing", tool="pytest", status=ReportEntryStatus.ERROR_ENCOUNTERED)]
)
def report(
    paths: List[str],
    html_report_directory: Optional[str] = None,
    verbose: bool = False,
    module_to_cover: Optional[str] = None,
    pytest_arguments: Optional[str] = None,
    pytest_parallel: Optional[str] = None,
) -> List[ReportEntry]:
    """
    Compute scores for testing.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param html_report_directory: Path to HTML report directory
    :type html_report_directory: Optional[str]
    :param verbose: Activate verbose mode
    :type verbose: bool
    :param module_to_cover: Module to cover with tests
    :type module_to_cover: Optional[str]
    :param pytest_arguments: Pytest arguments handler
    :type pytest_arguments: Optional[str]
    :param pytest_parallel: To run pytest in parallel execution
    :type pytest_arguments: Optional[str]

    :return: Test and Coverage results
    :rtype: List[ReportEntry]
    :raises RuntimeError: In case of none determined errors
    """

    with tempfile.TemporaryDirectory() as tmpdirname:
        # we read the values from the html files, so if an html report
        # is not requested, we generate one in a temporary folder
        if not html_report_directory:
            html_report_directory = tmpdirname

        args = argparse.Namespace(
            paths=paths,
            verbose=verbose,
            module_to_cover=module_to_cover,
            html_report_directory=html_report_directory,
            pytest_arguments=pytest_arguments,
            pytest_parallel=pytest_parallel,
        )

        exit_code = run(args)

        if exit_code not in [0, 1]:
            if exit_code == 2:
                print(
                    "PyTest encountered an error during collection or was manually interrupted. "
                    "See console output and HTML report for details."
                )
                return [
                    ReportEntry(
                        name="testing",
                        tool="pytest",
                        status=ReportEntryStatus.ERROR_ENCOUNTERED,
                    )
                ]
            elif exit_code == 5:
                print("PyTest found no tests to run in the given paths.")
                return [
                    ReportEntry(
                        name="testing",
                        tool="pytest",
                        status=ReportEntryStatus.ERROR_ENCOUNTERED,
                        message="No tests found.",
                        issues_count=0,
                    ),
                    ReportEntry(
                        name="test coverage",
                        tool="pytest-cov",
                        score=0.0,
                        issues_count=0,
                    ),
                ]
            else:
                # The remaining error codes that are allowed to cause a crash should not happen
                # in practice and indicate something went very wrong:
                # Exit code 3: Internal error happened while executing tests
                # Exit code 4: pytest command line usage error
                raise RuntimeError(f"Error when running pytest. Exit code {exit_code}")

        with open(f"{html_report_directory}/pytest/index.html") as report_file:
            report = report_file.read()
            # passed_tests = int(re.search('<span class="passed">([0-9]+) ', report)[1])
            failed_tests_field = re.search('<span class="failed">([0-9]+) ', report)
            error_tests_field = re.search('<span class="error">([0-9]+) ', report)
            if not failed_tests_field or not error_tests_field:
                raise RuntimeError("Error when parsing pytest report.")

            failed_tests = int(failed_tests_field[1])
            error_tests = int(error_tests_field[1])

        # This is just PASS/FAIL
        testing_report_status = (
            ReportEntryStatus.PASSED
            if failed_tests == 0 and error_tests == 0
            else ReportEntryStatus.FAILED
        )
        test_issues = failed_tests + error_tests

        rel_cov_score, cov_issues = None, None
        if module_to_cover:
            with open(f"{html_report_directory}/pytest-cov/index.html") as report_file:
                report = report_file.read()
                totals_section_match = re.search('<tr class="total">.*?</tr>', report, re.DOTALL)

                if not totals_section_match:
                    raise RuntimeError("Error when parsing pytest-cov report.")
                totals_section = totals_section_match[0]

                fields = re.findall("<td>([0-9]+)</td>", totals_section)
                values = tuple(int(field) for field in fields)
                statements_cov, missing_cov, excluded_cov = values

                rel_cov_score = 100 * (1 - missing_cov / statements_cov)
                cov_issues = missing_cov
        else:
            print("Skipping test coverage check. Pass `--coverage` with the module name to run it.")

    testing_report_entry = ReportEntry(
        name="testing",
        tool="pytest",
        status=testing_report_status,
        issues_count=0 if test_issues == "NA" else test_issues,
    )
    report_entries = [testing_report_entry]
    if module_to_cover is not None:
        test_coverage_report_entry = ReportEntry(
            name="test coverage",
            tool="pytest-cov",
            score=rel_cov_score,
            issues_count=cov_issues,
        )
        report_entries.append(test_coverage_report_entry)
    return report_entries
