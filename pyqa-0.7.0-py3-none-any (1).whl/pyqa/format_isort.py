# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Autoformatting Python source code using isort."""


import logging
import sys
import time
from typing import List

LOG = logging.getLogger(__name__)

DEFAULT_ARGS = ["--profile=black", "--line-length=100"]


def run(paths: List[str], verbose: bool, diff: bool, check_only: bool = False) -> int:
    """Run isort's code format and return isort's exit status.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param verbose: Verbose mode
    :type verbose: bool
    :param diff: Show the differences between the input files and the formatted ones
    :type diff: bool
    :param check_only: Checks that imports have been sorted, defaults to False
    :type check_only: bool
    :return: Exit code
    :rtype: int
    """
    tic = time.perf_counter()

    # Only perform expensive import if this function is called
    import isort.main

    if check_only:
        print("Checking imports...")
    else:
        print("Running isort...")

    argv = []
    if check_only:
        argv.append("--check")
    if verbose:
        argv.append("--verbose")
    if diff:
        argv.append("--diff")
    if sys.stdout.isatty():
        argv.append("--color")
    for arg in DEFAULT_ARGS:
        argv.append(arg)
    argv.extend(paths)

    exit_status: int = 0
    try:
        isort.main.main(argv)
    except SystemExit as exc:
        exit_status = int(exc.args[0])

    LOG.info("Exit status for isort is %d", exit_status)
    toc = time.perf_counter()
    print(f"Ran isort  in {toc-tic:0.4f} seconds")
    return exit_status
