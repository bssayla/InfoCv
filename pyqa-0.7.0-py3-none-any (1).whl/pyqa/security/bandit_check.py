# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Security Check on Python source code"""

import os
import re
import shlex
import sys
import tempfile
from typing import List, Optional

from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.safe_run import log_exception_and_return


@log_exception_and_return(1)
def run(
    paths: List[str],
    config: Optional[str] = None,
    bandit_arguments: Optional[str] = None,
    output_directory: Optional[str] = None,
    format: str = "html",
    verbose: bool = False,
    quiet: bool = False,
) -> int:
    """
    Run bandit checks.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param config: Configuration file
    :type config: Optional[str]
    :param bandit_arguments: Bandit arguments
    :type bandit_arguments: Optional[str]
    :param output_directory: Path to the output directory
    :type output_directory: Optional[str]
    :param format: Format of the output file
    :type format: str
    :param verbose: Verbose mode
    :type verbose: bool
    :param quiet: Quiet mode
    :type quiet: bool

    :return: Exit code
    :rtype: int
    """

    # Only perform import if this function is called
    import subprocess  # nosec

    print("Running bandit...")

    bandit_args = [sys.executable, "-m", "bandit"]
    if verbose:
        bandit_args.append("-v")
    if quiet:
        bandit_args.append("-q")
    if bandit_arguments:
        bandit_args.extend(shlex.split(bandit_arguments))
    if config:
        bandit_args.extend(["-c", config])
    else:
        if os.path.exists("bandit.yaml"):
            bandit_args.extend(["-c", "bandit.yaml"])

    if output_directory:
        os.makedirs(f"{output_directory}/bandit", exist_ok=True)
        bandit_args.extend(["-f", format])
        bandit_args.extend(["-o", f"{output_directory}/bandit/index.{format}"])

    bandit_args.append("-r")
    bandit_args.extend(paths)

    return subprocess.run(bandit_args).returncode  # nosec


@log_exception_and_return(
    ReportEntry(name="security check", tool="bandit", status=ReportEntryStatus.ERROR_ENCOUNTERED)
)
def report(
    paths: List[str],
    config: Optional[str] = None,
    bandit_arguments: Optional[str] = None,
    output_directory: Optional[str] = None,
) -> ReportEntry:
    """
    Compute scores for security.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param config: Configuration file
    :type config: Optional[str]
    :param bandit_arguments: Bandit arguments
    :type bandit_arguments: Optional[str]
    :param output_directory: Path to the output directory
    :type output_directory: Optional[str]

    :raises RuntimeError: In case of none determined errors

    :return: Security checks information for the report generation
    :rtype: ReportEntry
    """

    with tempfile.TemporaryDirectory() as tmpdirname:
        # we read the values from the html files, so if an html report
        # is not requested, we generate one in a temporary folder
        if not output_directory:
            output_directory = tmpdirname

        exit_code = run(
            paths,
            config=config,
            bandit_arguments=bandit_arguments,
            output_directory=output_directory,
            quiet=True,
        )
        # exit status other than 0 or 1 indicate bandit failed to run
        if exit_code not in [0, 1]:
            raise RuntimeError(f"Failed to run bandit. Exit status {exit_code}")

        error_counts_by_severity = []
        with open(f"{output_directory}/bandit/index.html") as report_file:
            report = report_file.read()

            total_lines_match = re.search('<span id="loc">([0-9]+)', report)
            total_lines_skipped = re.search('<span id="nosec">([0-9]+)', report)
            issues = len(re.findall('<div id="issue-', report))
            if total_lines_match and total_lines_skipped:
                print("Total lines of code:", int(total_lines_match[1]))
                print("Total lines skipped:", int(total_lines_skipped[1]))

            if issues != 0:
                low_issues = len(re.findall("<b>Severity: </b>LOW<br>", report))
                medium_issues = len(re.findall("<b>Severity: </b>MEDIUM<br>", report))
                high_issues = len(re.findall("<b>Severity: </b>HIGH<br>", report))
                error_counts_by_severity = [
                    f"high: {high_issues}",
                    f"medium: {medium_issues}",
                    f"low: {low_issues}",
                ]
                print(
                    "Total Issues found: ",
                    " | ".join(filter(lambda x: "0" not in x, error_counts_by_severity)),
                )
            if total_lines_match:
                total_lines = int(total_lines_match[1])
                print("No Issues Identified.")

            print(
                "More details in bandit HTML report :",
                os.path.abspath(f"{output_directory}/bandit/index.html"),
            )

            security_score = 100 * (1 - issues / total_lines)

    return ReportEntry(
        name="security check",
        tool="bandit",
        score=security_score,
        issues_count=error_counts_by_severity if error_counts_by_severity else 0,
    )
