# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Security Check on Python source code"""

import argparse
import sys
import time

from pyqa.security import bandit_check


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Add command-line arguments for security checks.

    :param subparsers: Subparsers to the main pyqa parser
    :type subparsers: argparse._SubParsersAction
    """
    parser = subparsers.add_parser("security", help="run security checks")
    parser.add_argument(
        "paths",
        nargs="+",
        help="paths to test directories",
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        help="specify output directory",
        dest="output_directory",
        required=("--format" or "-f") in sys.argv,
    )
    parser.add_argument(
        "-f",
        "--format",
        choices=["csv", "custom", "html", "json", "screen", "txt", "xml", "yaml"],
        default="html",
        help="specify output format",
        dest="format",
    )
    parser.add_argument(
        "--bandit-args", type=str, help="handle bandit arguments", dest="bandit_arguments"
    )
    parser.add_argument(
        "--bandit-config",
        help="path to bandit's configuration file, it could be a .YAML or .TOML file. "
        "Also a bandit.YAML file can be created and picked by defaults",
        dest="bandit_config",
    )
    parser.set_defaults(run_subcommand=run)


def run(args: argparse.Namespace) -> int:
    """
    Run static security checks.

    :param args: Parsed arguments from the ArgumentParser, including `paths`,
        `output_directory`, `format`, `bandit_args` and `bandit_config`
    :type args: argparse.Namespace

    :return: Exit code
    :rtype: int
    """

    tic = time.perf_counter()

    bandit_check_exit = bandit_check.run(
        args.paths,
        config=args.bandit_config,
        output_directory=args.output_directory,
        verbose=args.verbose,
        bandit_arguments=args.bandit_arguments,
        format=args.format,
    )
    toc = time.perf_counter()

    print(f"Ran bandit in {toc - tic:0.4f} seconds")

    exit_status = bandit_check_exit
    return exit_status
