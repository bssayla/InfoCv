# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Static style and code quality checks on Python source code."""

import ast
import logging
import re
import shlex
import tempfile
from datetime import date
from typing import Iterable, List, Optional, Tuple

import pydocstyle as pds
import pydocstyle.checker as pds_checker
import pydocstyle.parser as pds_parser
import pydocstyle.violations as pds_violations
from flake8_html.plugin import SEVERITY_NAMES, find_severity  # type: ignore

from pyqa import constants
from pyqa.constants import SPELLING_CODES
from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.safe_run import log_exception_and_return

LOG = logging.getLogger(__name__)
CURRENT_YEAR = date.today().year

# For a list of codes see:
#   * F: https://flake8.pycqa.org/en/latest/user/error-codes.html
#   * E, W: https://pycodestyle.pycqa.org/en/latest/intro.html#error-codes
#   * D: https://www.pydocstyle.org/en/stable/error_codes.html (some are already ignored by default)
#   * N: https://pypi.org/project/pep8-naming/
FLAKE8_IGNORE = (
    "D202",  # Incompatible with black: https://github.com/psf/black/issues/1052
    "D205",  # Multiline summaries are okay.
    "D400",  # Multiline summaries are okay.
    "E203",  # Incompatible with black: https://github.com/psf/black/issues/315
    "W503",  # Incompatible with W504.
    "B001",  # Avoid duplicate warnings when using flake8-bugbear.
)
DEFAULT_ARGS = [
    "--whitelist=allowlist.txt",
    "--dictionaries=en_US,python,technical,django,pandas",
    "--spellcheck-targets=comments",
    "--copyright-check",
    "--copyright-author=Oracle",
    rf"--copyright-regexp=Copyright\s+(\(C\)\s+)?(\d{{4}}\s*[-,]\s*)*{CURRENT_YEAR},?\s+%(author)s",
]


@log_exception_and_return((1, ()))
def run(
    paths: List[str],
    config: Optional[str] = None,
    html_report_directory: Optional[str] = None,
    output_file: Optional[str] = None,
    format: Optional[str] = None,
    ignore: Optional[str] = None,
    verbose: bool = False,
    flake8_arguments: Optional[str] = None,
    quiet: bool = False,
    spellcheck: bool = True,
    linter: bool = True,
) -> Tuple[int, Iterable[str]]:
    """Run flake8's code quality checks and return flake8's exit status.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :param output_file: Store the output in a file, defaults to None
    :type output_file: Optional[str]
    :param format: Format errors according to the chosen formatter, defaults to None
    :type format: Optional[str]
    :param ignore: Flake8 errors to ignore, defaults to None
    :type ignore: Optional[str]
    :param verbose: Verbose mode, defaults to False
    :type verbose: bool
    :param flake8_arguments: Arguments to be passed directly to flake8
    :type flake8_arguments: Optional[str]
    :param quiet: Quiet mode, defaults to False
    :type quiet: bool
    :param spellcheck: Enable spellchecking if True, Otherwise False
    :type spellcheck: bool
    :param linter: _Enable linting if True, Otherwise False
    :type linter: bool

    :return: Exit code and the checked paths
    :rtype: Tuple[int, Iterable[str]]
    """

    # Only perform expensive import if this function is called
    import flake8.defaults
    import flake8.main.application

    if not quiet:
        print("Running flake8...")

    # This is not public API, so it may break with a future version of flake8. We should
    # avoid using these non-public APIs as much as possible.
    #
    # In this case, this is the best known solution to ensure the following:
    #   * The defaults are changed without users of PyQA having to set them.
    #   * Users still have the option to override the default via `setup.cfg`.
    flake8.defaults.MAX_LINE_LENGTH = constants.MAX_LINE_LENGTH
    flake8.defaults.IGNORE = FLAKE8_IGNORE
    if not spellcheck:
        flake8.defaults.IGNORE = FLAKE8_IGNORE + SPELLING_CODES
    try:
        # Add copyright checks to the default codes selected by flake8.
        flake8.defaults.SELECT += ("C801",)
    except AttributeError:
        # We can safely ignore this as the checks are enabled by default in flake8 versions without
        # the 'SELECT' attribute.
        pass

    # We use the command-line interface because it is a stable, public API.
    argv = []
    argv.extend(DEFAULT_ARGS)
    if config is not None:
        argv.extend(["--config", config])
    if verbose:
        argv.append("--verbose")
    if html_report_directory is not None:
        argv.append("--format=html")
        argv.append(f"--htmldir={html_report_directory}")
    if output_file is not None:
        argv.extend(["--output-file", f"{output_file}"])
        if flake8.__version_info__ >= (5, 0, 0):
            argv.extend(["--color=never"])
    if not linter:
        select = ",".join(SPELLING_CODES) if spellcheck else ""
        argv.append(f"--select={select}")
    if ignore is not None:
        argv.append(f"--ignore={ignore}")
    if format is not None:
        argv.extend(["--format", f"{format}"])
    if flake8_arguments is not None:
        flake8_arg = shlex.split(flake8_arguments)
        for arg in flake8_arg:
            argv.append(arg)
    argv.extend(paths)

    app = flake8.main.application.Application()
    app.run(argv)
    checked_paths = [checker.filename for checker in app.file_checker_manager._all_checkers]
    error_codes = app.file_checker_manager.style_guide.stats.error_codes()
    try:
        app_exit = app.exit  # type: ignore
    except AttributeError:
        # Newer versions of flake8.
        exit_code = app.exit_code()
    else:
        # Older versions of flake8.
        try:
            app_exit()
        except SystemExit as exc:
            exit_code = exc.args[0]
        else:
            exit_code = 0

    exit_status = (
        0
        if all(p == "SC100" or p == "SC200" for p in error_codes) and len(error_codes) > 0
        else exit_code
    )

    LOG.info("Exit status for style checks is %s", exit_status)
    return exit_status, checked_paths


@log_exception_and_return(
    ReportEntry(name="code style checks", tool="flake8", status=ReportEntryStatus.ERROR_ENCOUNTERED)
)
def report_code_style(
    paths: List[str],
    config: Optional[str] = None,
    html_report_directory: Optional[str] = None,
    verbose: bool = False,
    flake8_arguments: Optional[str] = None,
) -> ReportEntry:
    """Compute scores for code style.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :param verbose: Verbose mode, defaults to False
    :type verbose: bool
    :param flake8_arguments: Flake8 arguments handler, defaults to None
    :type flake8_arguments: Optional[str]
    :raises RuntimeError: In case flake8 failed to run
    :return: Score and total flake8 errors
    :rtype: ReportEntry
    """
    flake8_ignore = FLAKE8_IGNORE + SPELLING_CODES

    exit_status, _ = run(
        paths,
        config=config,
        html_report_directory=f"{html_report_directory}/flake8",
        verbose=verbose,
        flake8_arguments=flake8_arguments,
        ignore=", ".join(flake8_ignore),
    )
    # exit status other than 0 or 1 indicate flake8 failed to run
    if exit_status not in [0, 1]:
        raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

    with tempfile.TemporaryDirectory() as tmpdirname:
        # Run flake8 as usual storing the output in a file
        exit_status, checked_paths = run(
            paths,
            config=config,
            format="pylint",
            output_file=f"{tmpdirname}/normal.flake8",
            quiet=True,
            flake8_arguments=flake8_arguments,
            ignore=", ".join(flake8_ignore),
        )
        if exit_status not in [0, 1]:
            raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

        # Remove lines indicating D1 errors, extract file name and line numbers,
        # then count unique lines with errors
        with open(f"{tmpdirname}/normal.flake8") as flake8_report:
            has_d1 = re.compile(".*\\[D1[0-9]{2}\\]")
            has_errors = re.compile(".*\\[([A-Z]{1,3}[0-9]{3})\\]")
            error_location = re.compile("(.*): \\[[A-Z]{1,3}[0-9]{3}\\]")

            lines = flake8_report.read().split("\n")
            lines_not_d1 = list(filter(lambda x: not has_d1.match(x), lines))
            matches = list(map(error_location.match, lines_not_d1))
            # Collect all the violations code from the file
            error_prefix = list(map(has_errors.match, lines_not_d1))
            errors = [match[1] for match in error_prefix if match is not None]
            error_locations = [match[1] for match in matches if match is not None]

            # Sort the violations by degree of severity
            severity_counts = _count_errors_by_severity(errors)
            severity_counts = [f"{key}: {val}" for key, val in severity_counts.items()]

            issues_count = 0 if len(error_locations) == 0 else severity_counts
            total_lines_with_errors = len(set(error_locations))

    total_lines = 0
    for path in checked_paths:
        with open(path) as file:
            total_lines += len(file.readlines())

    relative_score = 100 * (1 - (total_lines_with_errors / total_lines))

    return ReportEntry(
        name="code style checks",
        issues_count=issues_count,
        score=relative_score,
        tool="flake8",
    )


@log_exception_and_return(
    ReportEntry(
        name="code spell checks",
        tool="flake8-spellchecks",
        status=ReportEntryStatus.ERROR_ENCOUNTERED,
    )
)
def report_code_spell_checker(
    paths: List[str],
    config: Optional[str] = None,
    html_report_directory: Optional[str] = None,
    verbose: bool = False,
) -> ReportEntry:
    """Compute scores for code spell check.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :param verbose: Verbose mode, defaults to False
    :type verbose: bool
    :raises RuntimeError: In case flake8 failed to run
    :return: Score and total flake8 spellcheck errors
    :rtype: ReportEntry
    """
    exit_status, _ = run(
        paths,
        config=config,
        html_report_directory=f"{html_report_directory}/flake8-spellchecks",
        format="html",
        verbose=verbose,
        quiet=True,
        linter=False,
    )
    # exit status other than 0 or 1 indicate flake8 failed to run
    if exit_status not in [0, 1]:
        raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

    with tempfile.TemporaryDirectory() as tmpdirname:
        # Run flake8 as usual storing the output in a file
        exit_status, checked_paths = run(
            paths,
            config=config,
            format="pylint",
            output_file=f"{tmpdirname}/normal.flake8",
            quiet=True,
            linter=False,
        )
        if exit_status not in [0, 1]:
            raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

        # extract file name and line numbers, then count unique lines with errors.
        with open(f"{tmpdirname}/normal.flake8") as flake8_report:
            spell_error_location = re.compile("(.*): \\[SC[0-9]{3}\\]")
            lines = flake8_report.read().split("\n")
            matches = list(map(spell_error_location.match, lines))
            spell_error_locations = [match[1] for match in matches if match is not None]
            total_errors = len(spell_error_locations)
            total_lines_with_spell_errors = len(set(spell_error_locations))

    total_lines = 0
    for path in checked_paths:
        with open(path) as file:
            total_lines += len(file.readlines())

    relative_spell_score = 100 * (1 - (total_lines_with_spell_errors / total_lines))

    return ReportEntry(
        name="code spell checks",
        tool="flake8-spellchecks",
        issues_count=total_errors,
        score=relative_spell_score,
    )


def _count_errors_by_severity(errors: List[str]):
    """Count flake8 errors by severity

    :param errors: Flake8 error codes
    :type errors: List[str]
    :return: Number of flake8 errors by severity
    :rtype: dict[str, int]
    """
    severity_dict = {"high": 0, "medium": 0, "low": 0}
    for err in errors:
        severity = find_severity(err)
        severity_dict[SEVERITY_NAMES[severity - 1]] += 1
    return severity_dict


@log_exception_and_return(
    ReportEntry(
        name="documentation coverage", tool="flake8", status=ReportEntryStatus.ERROR_ENCOUNTERED
    )
)
def report_doc_coverage(
    paths: List[str],
    config: Optional[str] = None,
    html_report_directory: Optional[str] = None,
    verbose: Optional[bool] = None,
    flake8_arguments: Optional[str] = None,
) -> ReportEntry:
    """Compute scores for documentation style.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :param verbose: Verbose mode, defaults to None
    :type verbose: Optional[bool]
    :param flake8_arguments: Flake8 arguments handler, defaults to None
    :type flake8_arguments: Optional[str]
    :raises RuntimeError: In case flake8 failed to run
    :return: Score and total docstring errors
    :rtype: ReportEntry
    """
    with tempfile.TemporaryDirectory() as tmpdirname:
        exit_status, _ = run(
            paths,
            config=config,
            output_file=f"{tmpdirname}/orig.flake8",
            quiet=True,
            flake8_arguments=flake8_arguments,
        )
        if exit_status not in [0, 1]:
            raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

        with _Flake8PossibleDocstrings():
            exit_status, _ = run(paths, output_file=f"{tmpdirname}/count.flake8", quiet=True)
            if exit_status not in [0, 1]:
                raise RuntimeError(f"Failed to run flake8. Exit status {exit_status}")

        total_errors = _count_errors_from_file(f"{tmpdirname}/orig.flake8", "D1")
        total_possible_errors = _count_errors_from_file(f"{tmpdirname}/count.flake8", "D8")

    relative_score = 100 * (1 - total_errors / total_possible_errors)

    return ReportEntry(
        name="documentation coverage",
        tool="flake8",
        issues_count=total_errors,
        score=relative_score,
    )


def _count_errors_from_file(filename: str, prefix: str) -> int:
    """Count errors from file

    :param filename: Filename
    :type filename: str
    :param prefix: Error code prefix
    :type prefix: str
    :return: Number of errors found
    :rtype: int
    """
    with open(filename) as report:
        error_code = re.compile(f".*: {prefix}[0-9]{{2}}")

        lines = report.read().split("\n")
        return len(list(filter(error_code.match, lines)))


class _Flake8PossibleDocstrings:
    def __enter__(self):
        # Store the old status
        self.all_errors_old = pds_violations.all_errors
        self.conventions_old = pds.conventions
        self.orig_check = pds_checker.ConventionChecker.check_docstring_missing

        # Create the error group and the errors
        d8xx = pds_violations.ErrorRegistry.create_group("D8", "Possible missing Docstrings")
        d800 = d8xx.create_error("D800", "Possible missing docstring in public module")
        d801 = d8xx.create_error("D801", "Possible missing docstring in public class")
        d802 = d8xx.create_error("D802", "Possible missing docstring in public method")
        d803 = d8xx.create_error("D803", "Possible missing docstring in public function")
        d804 = d8xx.create_error("D804", "Possible missing docstring in public package")
        d805 = d8xx.create_error("D805", "Possible missing docstring in magic method")
        d806 = d8xx.create_error("D806", "Possible missing docstring in public nested class")
        d807 = d8xx.create_error("D807", "Possible missing docstring in __init__")

        # Define the check function
        @pds_checker.check_for(pds_parser.Definition, terminal=True)
        def check_docstring_missing_possible(self, definition, docstring):
            """D80{0,1,2,3}: Public definitions should have docstrings.

            These errors happen for all functions that accept a docstring,
            ignoring if the docstring exists or not.

            :param definition: Definition of the functions, methods,classes...
            :param docstring: Docstring
            :return: Docstring errors

             # noqa: DAR101 self
            """
            from pydocstyle.parser import (
                Class,
                Function,
                Method,
                Module,
                NestedClass,
                NestedFunction,
                Package,
            )
            from pydocstyle.utils import is_blank

            if definition.is_public or docstring and is_blank(ast.literal_eval(docstring)):
                codes = {
                    Module: d800,
                    Class: d801,
                    NestedClass: d806,
                    Method: lambda: d805()
                    if definition.is_magic
                    else (
                        d807()
                        if definition.is_init
                        else (d802() if not definition.is_overload else None)
                    ),
                    NestedFunction: d803,
                    Function: (lambda: d803() if not definition.is_overload else None),
                    Package: d804,
                }
                ret = codes[type(definition)]()

                return ret

        # Remove old check function from pydocstyle
        delattr(pds_checker.ConventionChecker, "check_docstring_missing")

        # Add the new check function to pydocstyle
        pds_checker.ConventionChecker.check_docstring_missing_possible = (
            check_docstring_missing_possible
        )

        pds_violations.all_errors = set(pds_violations.ErrorRegistry.get_error_codes())
        pds.conventions = pds_violations.AttrDict(
            {
                k: {"D800", "D801", "D802", "D803", "D804", "D805", "D806", "D807"}
                for k, v in pds.conventions.items()
            }
        )

    def __exit__(self, type, value, traceback):
        # Remove the check function
        delattr(pds_checker.ConventionChecker, "check_docstring_missing_possible")
        # Remove the error group (assumes no other group has been added)
        pds_violations.ErrorRegistry.groups = list(
            filter(lambda grp: grp.prefix != "D8", pds_violations.ErrorRegistry.groups)
        )
        pds_violations.all_errors = self.all_errors_old
        pds.conventions = self.conventions_old
        pds_checker.ConventionChecker.check_docstring_missing = self.orig_check
