# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Creating a health report showing the quality of Python code."""

import argparse
import time
from pathlib import Path
from typing import List

from pyqa import formatting
from pyqa.constants import LEVELS
from pyqa.formatting import autoformatting_step_selector
from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.step_selector import SUBSTEP_SEPARATOR, StepSelector

reporting_step_selector = StepSelector(
    ["linter", "spellcheck", "testing", "typecheck", "security", "duplication"]
    + [f"autoformat{SUBSTEP_SEPARATOR}{tool}" for tool in autoformatting_step_selector.steps]
)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Add command-line arguments for health reporting.

    :param subparsers: Subparsers to the main pyqa parser
    :type subparsers: argparse._SubParsersAction

    """
    parser_report = subparsers.add_parser("report", help="generate a health report")
    reporting_step_selector.add_parser_arguments(parser_report)
    parser_report.add_argument(
        "paths",
        nargs="+",
        help="paths to Python files or directories",
    )
    parser_report.add_argument("--config", help="configuration file to use")
    parser_report.add_argument(
        "--output-dir",
        help="generate html report in directory",
        action="store",
        dest="html_report_directory",
        required=True,
    )
    parser_report.add_argument(
        "--type-precision",
        help="minimum type precision percentage to pass the quality check",
        type=float,
        default=50,
        action="store",
        dest="precision_percent",
    )
    parser_report.add_argument(
        "--coverage-score",
        help="coverage score to pass the quality check",
        type=float,
        default=80,
        action="store",
        dest="coverage_score",
    )
    parser_report.add_argument("--coverage", help="module name to cover", dest="module_to_cover")
    parser_report.add_argument(
        "--severity-level",
        type=str,
        default="medium",
        choices=["low", "medium", "high"],
        help="specify the level of severity {low, medium, high} to pass security check",
        dest="severity_level",
    )
    parser_report.add_argument(
        "--pytest-args", type=str, help="Handle pytest arguments", dest="pytest_arguments"
    )
    parser_report.add_argument(
        "--flake8-args", type=str, help="Handle flake8 arguments", dest="flake8_arguments"
    )
    parser_report.add_argument(
        "--mypy-args", type=str, help="Handle mypy arguments", dest="mypy_arguments"
    )
    parser_report.add_argument(
        "--bandit-args", type=str, help="Handle bandit arguments", dest="bandit_arguments"
    )
    parser_report.add_argument(
        "--bandit-config", help="path to bandit's configuration file", dest="bandit_config"
    )

    parser_report.set_defaults(run_subcommand=run)


def generate_report_details(args: argparse.Namespace) -> List[ReportEntry]:
    """
    Create the health report.

    :param args: Parsed arguments from the ArgumentParser, including `path`,\
    `config`, `html_report_directory`, `precision_percent`, `coverage_score`,\
    `module_to_cover`, `pytest_arguments`, `flake8_arguments` and `mypy_arguments`
    :type args: argparse.Namespace

    :return: Report details
    :rtype: Dict
    """
    # Only perform expensive import if this function is called
    from pyqa import duplication_checks, stylecheck, test_cover, typecheck
    from pyqa.security import bandit_check

    steps = reporting_step_selector.selected_steps_set(args)

    Path(args.html_report_directory).mkdir(parents=True, exist_ok=True)

    report_entries: List[ReportEntry] = []

    if "linter" in steps:
        tic = time.perf_counter()
        code_style_report_entry = stylecheck.report_code_style(
            args.paths,
            config=args.config,
            html_report_directory=args.html_report_directory,
            verbose=args.verbose,
            flake8_arguments=args.flake8_arguments,
        )
        report_entries.append(code_style_report_entry)
        doc_coverage_report_entry = stylecheck.report_doc_coverage(
            args.paths,
            config=args.config,
            verbose=args.verbose,
            flake8_arguments=args.flake8_arguments,
        )
        report_entries.append(doc_coverage_report_entry)
        toc = time.perf_counter()
        print(f"Ran flake8 in {toc - tic:0.4f} seconds")

    autoformatting_tools = sorted(
        step.split(SUBSTEP_SEPARATOR)[1] for step in steps if step.startswith("autoformat")
    )
    if autoformatting_tools:
        autoformatting_report_entries = formatting.report_autoformatting(
            args.paths, autoformatting_tools, args.html_report_directory
        )
        report_entries.extend(autoformatting_report_entries)

    if "spellcheck" in steps:
        tic = time.perf_counter()
        print("Running flake8-spellcheck...")
        spell_check_report_entry = stylecheck.report_code_spell_checker(
            args.paths,
            config=args.config,
            html_report_directory=args.html_report_directory,
            verbose=args.verbose,
        )
        report_entries.append(spell_check_report_entry)
        toc = time.perf_counter()
        print(f"Ran flake8-spellcheck in {toc - tic:0.4f} seconds")

    if "duplication" in steps:
        tic = time.perf_counter()
        code_duplication_report_entry = duplication_checks.report_duplication(
            args.paths, html_report_directory=args.html_report_directory
        )
        report_entries.append(code_duplication_report_entry)
        toc = time.perf_counter()
        print(f"Ran pylint in {toc - tic:0.4f} seconds")

    if "typecheck" in steps:
        type_checking_report_entries = typecheck.report_precision(
            args.paths,
            mypy_arguments=args.mypy_arguments,
            html_report_directory=args.html_report_directory,
            verbose=args.verbose,
        )
        report_entries.extend(type_checking_report_entries)

    if "security" in steps:
        tic = time.perf_counter()
        security_check_report_entry = bandit_check.report(
            args.paths,
            config=args.bandit_config,
            output_directory=args.html_report_directory,
            bandit_arguments=args.bandit_arguments,
        )
        report_entries.append(security_check_report_entry)
        toc = time.perf_counter()
        # Show the global execution time for Security check
        print(f"Ran bandit in {toc - tic:0.4f} seconds")

    if "testing" in steps:
        test_report_entries = test_cover.report(
            args.paths,
            html_report_directory=args.html_report_directory,
            module_to_cover=args.module_to_cover,
            verbose=args.verbose,
            pytest_arguments=args.pytest_arguments,
        )
        report_entries.extend(test_report_entries)

    return report_entries


def run(args: argparse.Namespace) -> int:
    """
    Create the health report.

    :param args: Parsed arguments from the ArgumentParser, including `path`,\
    `config`, `html_report_directory`, `precision_percent`, `coverage_score`,\
    `module_to_cover`, `pytest_arguments`, `flake8_arguments` and `mypy_arguments`
    :type args: argparse.Namespace

    :return: Exit code
    :rtype: int
    """
    # Only perform expensive import if this function is called
    from pyqa.reporting import html_report

    report_entries = generate_report_details(args)

    html_report.generate_report_html_index(args.html_report_directory, report_entries)

    # the issues are being filtered depending on which should make the report fail
    report_entries_success = [
        # Typechecking has a precision score above the target threshold
        (report_entry.name == "type precision" and report_entry.score >= args.precision_percent)
        # Test coverage is above the target threshold
        or (report_entry.name == "test coverage" and report_entry.score >= args.coverage_score)
        # Spellcheck issues do not lead to failing reports
        or (report_entry.name == "code spell checks")
        # Detected security issue pass
        or (
            report_entry.name == "security check"
            and satisfies_security(report_entry.issues_count, args.severity_level)
        )
        # Code duplication issues do not lead to failing reports
        or (report_entry.name == "duplication checks")
        # The count of issues is 0
        or report_entry.issues_count == 0
        # The status is PASSED
        or report_entry.status == ReportEntryStatus.PASSED
        for report_entry in report_entries
    ]

    exit_code = 0 if all(report_entries_success) else 1
    return exit_code


def satisfies_security(issues, severity_level) -> bool:
    """
    Verify if the issues satisfy the security level.

    :param issues: List of the found security issues.
    :type issues: Iterable[str]
    :param severity_level: The security level to satisfy {High,Medium,Low}
    :type issues: str

    :return: True if no issues beyond the severity level, False otherwise.
    :rtype: bool
    """
    return issues != 0 and all(
        [
            {z[0]: int(z[1]) for z in map(lambda x: x.split(": "), issues)}[level] == 0
            for level in LEVELS[LEVELS.index(severity_level) :]
        ]
    )
