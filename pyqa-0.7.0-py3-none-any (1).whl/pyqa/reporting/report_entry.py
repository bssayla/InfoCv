# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Defining the type of data supported by PyQA report generator"""

from enum import Enum
from typing import List, Optional, Union


class ReportEntryStatus(Enum):
    """Define possible status for a report entry"""

    PASSED = "PASSED"  # Check ran successfully and passed
    FAILED = "FAILED"  # Check ran successfully and found issues
    ERROR_ENCOUNTERED = "Error encountered"  # Checks failed to run


class ReportEntry:
    """contains data for a single entry to be displayed in reports"""

    def __init__(
        self,
        name: str,
        tool: str,
        issues_count: Optional[Union[int, List[str]]] = None,
        score: Optional[float] = None,
        status: Optional[ReportEntryStatus] = None,
        message: Optional[str] = None,
    ):
        """
        Contains information related to one entry in PyQA's reports

        :param name: The name of the entry
        :type name: str
        :param tool: The name of the tool used for this report entry
        :type tool: str
        :param issues_count: The number of detected issue, or a List[str] of length 3.
        :type issues_count: Optional[Union[int, List[str]]] = None
        :param score: A score associated to the entry (will be displayed as a percentage)
        :type score: Optional[float] = None
        :param status: The status of the entry PASSED/FAILED
        :type status: Optional[ReportEntryStatus] = None
        :param message: A message that may be displayed in the reports
        :type message: Optional[str] = None
        """
        self.name = name
        self.tool = tool
        self.issues_count = issues_count
        self.score = score
        self.status = status
        self.message = message
