# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Python code quality assurance tool.

This package provides the implementation of the pyqa report command. Reporting includes
generation of scores for different categories summarized in html files.
"""
