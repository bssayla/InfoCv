# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Creating a HTML files for health report showing the quality of Python code."""

import os
import shutil
from string import Template
from typing import List

import pkg_resources

from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus


def generate_report_html_index(directory: str, report_entries: List[ReportEntry]):
    """
    Generate report html index file summarizing the scores collected.

    :param directory: Path of the report directory
    :type directory: str
    :param report_entries: Dictionary of the report details
    :type report_entries: List[ReportEntry]
    """
    resource_path: str = os.path.join("templates", "index.html")
    bytes_data: bytes = pkg_resources.resource_string("pyqa.reporting", resource_path)
    html_template = Template(str(bytes_data, "utf-8"))
    full_path = os.path.abspath(f"{directory}/index.html")
    columns = shutil.get_terminal_size().columns
    index_file = open(f"{directory}/index.html", "w")

    table_entries: str = ""
    for entry in report_entries:
        # If no score is provided we potentially display the status (see ReportEntryStatus)
        score_str = ""
        if entry.status == ReportEntryStatus.ERROR_ENCOUNTERED:
            score_str = entry.message or entry.status.value
        elif entry.score is not None:
            score_str = f"{entry.score:.2f} %"
        elif entry.status is not None:
            score_str = entry.status.value

        if isinstance(entry.issues_count, list):
            issues = "\n".join([f"<td>{issue}</td>" for issue in entry.issues_count])
        else:
            issues_str = (
                "See dedicated page" if entry.issues_count is None else f"{entry.issues_count}"
            )
            issues = f'<td colspan="3">{issues_str}</td>'

        table_entries += f"""
            <tr>
                <td>{entry.name}</td>
                <td><a href="{entry.tool}/index.html">{entry.tool} detailed report</a></td>
                <td>{score_str}</td>
                {issues}
            </tr>
        """

    index_file.write(html_template.substitute(table_entries=table_entries))
    index_file.close()

    print(f" Generated PyQA HTML report: {full_path} ".center(columns, "*"))
