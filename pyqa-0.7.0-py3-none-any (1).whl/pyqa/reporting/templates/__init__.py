# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Python code quality assurance tool.

This package contains templates for html report generation. No public API for Python code
is provided in this package.
"""
