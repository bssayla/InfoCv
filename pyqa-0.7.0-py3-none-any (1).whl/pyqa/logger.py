# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Log messages.

This module is not called 'logging' to avoid a name clash with the built-in logging module.
"""

import logging

LOG = logging.getLogger("pyqa")


def configure(verbose: bool) -> None:
    """
    Configure the output of log messages.

    :param verbose: Activate verbose mode (logging level is set to INFO instead of WARNING)
    :type verbose: bool
    """

    if verbose:
        level = "INFO"
    else:
        level = "WARNING"

    formatter = logging.Formatter("{levelname} [{name}] {message}", style="{")
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)

    LOG.addHandler(handler)
    LOG.setLevel(level)
    LOG.info("Set the log level for pyqa to %s", level)
