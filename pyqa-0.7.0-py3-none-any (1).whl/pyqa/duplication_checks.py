# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Duplication checks on Python source code."""
import contextlib
import logging
import os
import re
import tempfile
from string import Template
from typing import List, Optional

import pkg_resources

from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.safe_run import log_exception_and_return

LOG = logging.getLogger(__name__)


@log_exception_and_return(1)
def run(
    paths: List[str],
    quiet: bool = False,
) -> int:
    """Run pylint and return pylint's exit status.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param quiet: Quiet mode, defaults to False
    :type quiet: bool
    :return: Exit code
    :rtype: int
    """
    # Only perform expensive import if this function is called
    import pylint  # type: ignore

    if not quiet:
        print("Running pylint...")

    exit_status = 0
    try:
        pylint.run_symilar(get_files(paths))
    except SystemExit as exc:
        exit_status = int(exc.args[0])

    LOG.info("Exit status for pylint is %s", exit_status)
    return exit_status


def get_files(paths):
    """List files in directory and subdirectories with extension py

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :return: List of file names
    :rtype: List[str]
    """
    files = ["--ignore-comments", "--ignore-docstrings", "--ignore-imports", "--ignore-signatures"]
    for path in paths:
        if os.path.isfile(path):
            files.append(path)
        else:
            for dir_path, _, file_names in os.walk(path):
                for file in file_names:
                    if file.endswith(".py"):
                        files.append(os.path.join(dir_path, file))
    return files


@log_exception_and_return(
    ReportEntry(
        name="duplication checks",
        tool="pylint-duplication",
        status=ReportEntryStatus.ERROR_ENCOUNTERED,
    )
)
def report_duplication(
    paths: List[str],
    html_report_directory: Optional[str],
) -> ReportEntry:
    """Compute scores for code duplicate.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :raises RuntimeError: In case pylint failed to run
    :return: Score and number of duplicated lines
    :rtype: ReportEntry
    """
    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(f"{tmpdirname}/output.txt", "w") as out, open(
            f"{tmpdirname}/error.txt", "w"
        ) as err:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                exit_status = run(paths)

        stdout_report = ""
        try:
            with open(f"{tmpdirname}/output.txt") as report:
                for lines in report.readlines():
                    stdout_report += "<pre>" + lines + "</pre>"
        except FileNotFoundError:
            pass
        stderr_report = None
        try:
            with open(f"{tmpdirname}/error.txt") as report:
                stderr_report = report.read()
        except FileNotFoundError:
            pass

        os.makedirs(f"{html_report_directory}/pylint-duplication", exist_ok=True)
        with open(f"{html_report_directory}/pylint-duplication/index.html", "w") as html_report:
            html_report.write(pylint_html_format(stdout_report, stderr_report))

        if exit_status not in [0, 1]:
            raise RuntimeError(f"Failed to run pylint. Exit status {exit_status}")

        with open(f"{tmpdirname}/output.txt") as pylint_report:
            last_nonempty_line = next(
                line for line in reversed(pylint_report.readlines()) if line.strip()
            )

            duplicated_lines_match = re.search(r"duplicates=([0-9]*)?", last_nonempty_line)
            total_lines_match = re.search("lines=([0-9]+)?", last_nonempty_line)

            total_lines = int(total_lines_match[1]) if total_lines_match else 0
            duplicated_lines = int(duplicated_lines_match[1]) if duplicated_lines_match else 0
            score = 100 * (1 - (duplicated_lines / total_lines))

            print("Running pylint ...\nTotal lines checked:", total_lines)
            print("Total duplicated lines:", duplicated_lines)
            print(f"Score: {score:0.2f}%")

    return ReportEntry(
        name="duplication checks",
        tool="pylint-duplication",
        score=score,
        issues_count=duplicated_lines,
    )


def pylint_html_format(report: str, error: Optional[str] = None) -> str:
    """Generate report html index file summarizing the scores collected.

    :param report: Stdout from 'pylint' to report
    :type report: str
    :param error: Stderr from 'pylint' to report, defaults to None
    :type error: Optional[str]
    :return: Template string
    :rtype: str
    """

    resource_path: str = os.path.join("templates", "pylint_report.html")
    bytes_data: bytes = pkg_resources.resource_string("pyqa.reporting", resource_path)
    html_template = Template(str(bytes_data, "utf-8"))

    report = re.sub("(.*)", r'<span class="str">\1</span>', report)
    report = re.sub("([0-9]+)", r'<span class="num">\1</span>', report)
    report = re.sub(r"(==.*\.py)", r'<span class="report">\1</span>', report)

    if error:
        err_report = error.replace("\n", "<br>\n")
    else:
        err_report = ""
    return html_template.substitute(
        report_output=report,
        error_output=err_report,
        display_err="block" if error else "none",
    )
