# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""pyqa is an automated tool for Python code quality assurance.

It can be run on the command line or as part of an automated build task or CI/CD process.
"""

# 'PyQA' is the name of this project, 'pyqa' is the spelling of the application and the package.

import argparse
import sys
import time

from pyqa import checking, formatting, logger, test_cover
from pyqa.reporting import reporting
from pyqa.security import checking as security_checking


def main() -> None:
    """Configure logger and run the correct subcommand with its arguments."""

    tic = time.perf_counter()
    parser = setup_parser()
    args = parser.parse_args(sys.argv[1:])
    logger.configure(args.verbose)
    if args.subcommand is None:
        parser.print_help(sys.stderr)
        exit_status = 1
    else:
        exit_status = args.run_subcommand(args)
    toc = time.perf_counter()
    print(f"Ran pyqa in {toc-tic:0.4f} seconds")
    sys.exit(exit_status)


def setup_parser() -> argparse.ArgumentParser:
    """
    Set up an ArgumentParser with common arguments and subcommand-specific arguments.

    :return: Argument parser
    :rtype: argparse.ArgumentParser
    """

    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    # Add common arguments
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="print more verbose log messages",
    )

    subparsers = parser.add_subparsers(
        title="subcommands",
        dest="subcommand",
        help="""Use `pyqa {subcommand} --help` to see
                                       subcommand-specific help""",
    )
    # Let each subcommand add its own arguments
    checking.add_subparser(subparsers)
    test_cover.add_subparser(subparsers)
    formatting.add_subparser(subparsers)
    security_checking.add_subparser(subparsers)
    reporting.add_subparser(subparsers)

    return parser


if __name__ == "__main__":
    main()
