# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Common functionalities for argument parsers."""

import argparse
from typing import List, Set

SUBSTEP_SEPARATOR = "_"


class StepSelector:
    """This class enables subcommands with multiple steps to configure which steps to run or skip.

    Usage:
    1. define the step selector
    ```
    my_step_selector = StepSelector(steps)
    ```
    2. use it to modify the argparse's Argument parser
    ```
    my_step_selector.add_parser_arguments(parser)
    ```
    3. use it to compute the set of steps that should run based on passed arguments
    ```
    steps = my_step_selector.selected_steps_set(args)
    ```
    """

    def __init__(self, steps: List[str]):
        """
        Save steps and compute complete list of choices including all substeps.

        :param steps: List of all steps of the subcommand
        :type steps: List[str]
        """
        self.steps = steps
        self.choices = list(
            set(
                [
                    *[choice for step in steps for choice in step.split(SUBSTEP_SEPARATOR)],
                    *self.steps,
                ]
            )
        )

    def add_parser_arguments(self, parser: argparse.ArgumentParser) -> None:
        """
        Add argument --steps and --skip-steps for steps selection to the parser

        :param parser: Argument parser
        :type parser: argparse.ArgumentParser
        """
        parser.add_argument(
            "--steps",
            choices=self.choices,
            nargs="+",
            help="Specify which tasks should be run",
            default=self.choices,
        )
        parser.add_argument(
            "--skip-steps",
            choices=self.choices,
            nargs="+",
            help="Specify which tasks should be skipped",
            default=[],
        )

    def selected_steps_set(self, args) -> Set[str]:
        """
        Return set of selected steps based on command's arguments.

        :param args: Parsed arguments from the ArgumentParser, including `steps` and `skip_steps`

        :return: Set of the selected steps
        :rtype: Set[str]
        """

        def is_selected(step):
            if step in args.skip_steps or any(
                substep in args.skip_steps for substep in step.split(SUBSTEP_SEPARATOR)
            ):
                return False
            if step in args.steps or any(
                substep in args.steps for substep in step.split(SUBSTEP_SEPARATOR)
            ):
                return True
            return False

        return set(step for step in self.steps if is_selected(step))
