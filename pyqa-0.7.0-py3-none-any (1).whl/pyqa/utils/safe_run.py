# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Utils used cross modules."""
import functools
import traceback
from typing import Callable, TypeVar, cast

TCallable = TypeVar("TCallable", bound=Callable)


def log_exception_and_return(default_value=None):
    """
    Generate a decorator to safe run method and return default value.

    :param default_value: Default value to return

    :return: Results of the callable function
    """

    def safe_run(func: TCallable) -> TCallable:
        @functools.wraps(func)
        def inner_function(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception:
                traceback.print_exc()
                return default_value

        return cast(TCallable, inner_function)

    return safe_run
