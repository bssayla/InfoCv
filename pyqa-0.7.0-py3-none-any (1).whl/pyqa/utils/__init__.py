# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""
Python code quality assurance tool.

This package provides common helper functions.
"""
