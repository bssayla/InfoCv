# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Autoformatting Python source code."""

import argparse
import contextlib
import os
import time
from typing import List

from pyqa import format_black, format_isort
from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.step_selector import StepSelector

autoformatting_step_selector = StepSelector(["black", "isort"])


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Add command-line arguments for autoformatting.

    :param subparsers: Subparsers to the main pyqa parser
    :type subparsers: argparse._SubParsersAction
    """
    parser_format = subparsers.add_parser("format", help="run autoformatting")
    autoformatting_step_selector.add_parser_arguments(parser_format)
    parser_format.add_argument(
        "paths",
        nargs="+",
        help="paths to Python files or directories",
    )
    parser_format.add_argument(
        "--diff",
        action="store_true",
        help=(
            "Show differences between the input files and the formatted ones, on stdout."
            "These differences will not be saved in the files."
        ),
    )
    parser_format.add_argument(
        "--check-only",
        action="store_true",
        help=(
            "Checks whether files will be modified by autoformatting." "Files will not be modified."
        ),
    )

    parser_format.set_defaults(run_subcommand=run)


def run(args: argparse.Namespace) -> int:
    """Run autoformatting.

    :param args: Arguments for autoformatting
    :type args: argparse.Namespace
    :return: Exit code
    :rtype: int
    """
    exit_codes = [0]

    steps = autoformatting_step_selector.selected_steps_set(args)

    if "isort" in steps:
        isort_exit = format_isort.run(
            args.paths, verbose=args.verbose, diff=args.diff, check_only=args.check_only
        )
        exit_codes.append(isort_exit)
    else:
        print("Skipped sorting imports")

    if "black" in steps:
        black_exit = format_black.run(
            args.paths, verbose=args.verbose, diff=args.diff, check_only=args.check_only
        )
        exit_codes.append(black_exit)
    else:
        print("Skipped autoformatting with black")

    # Return exit code to ensure that any problems are reported in the exit code.
    exit_status = max(exit_codes)
    return exit_status


def report_autoformatting(
    paths: List[str], tools: List[str], html_report_directory: str
) -> List[ReportEntry]:
    """Write dedicated html files for reports and computes report details.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param tools: Names of supported tools for autoformatting. Currently only black or isort
    :type paths: List[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: str

    :raises ValueError: When specified tools are unsupported
    :return: Report detail Dict
    :rtype: Dict[str, Dict[str, object]]
    """
    report_entries = []

    for tool in tools:
        print(f"Checking formatting with {tool}...")
        tic = time.perf_counter()

        os.makedirs(f"{html_report_directory}/{tool}", exist_ok=True)
        with open(f"{html_report_directory}/{tool}/index.html", "w") as html_report:
            html_report.write(f"<h1>{tool} output</h1>")
            html_report.write("<pre>")
            with contextlib.redirect_stdout(html_report), contextlib.redirect_stderr(html_report):
                if tool == "black":
                    exit_code = format_black.run(paths, verbose=False, diff=False, check_only=True)
                elif tool == "isort":
                    exit_code = format_isort.run(paths, verbose=False, diff=False, check_only=True)
                else:
                    raise ValueError(f"Found tool {tool} which is not supported for autoformatting")
            html_report.write("</pre>")
        new_entry = ReportEntry(
            name=f"autoformatting {tool}",
            tool=tool,
            status=ReportEntryStatus.FAILED if exit_code > 0 else ReportEntryStatus.PASSED,
            issues_count=0 if exit_code == 0 else None,
        )
        report_entries.append(new_entry)
        toc = time.perf_counter()
        print(f"Ran {tool} in {toc-tic:0.4f} seconds")

    return report_entries
