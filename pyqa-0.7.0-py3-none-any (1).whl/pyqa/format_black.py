# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Autoformatting Python source code using black."""


import logging
import sys
import time
from typing import List

from pyqa import constants
from pyqa.utils.safe_run import log_exception_and_return

LOG = logging.getLogger(__name__)


@log_exception_and_return(1)
def run(paths: List[str], verbose: bool, diff: bool, check_only: bool = False) -> int:
    """Run black's code format and return black's exit status.

    :param paths: Paths to Python files or directories
    :type paths: List[str]
    :param verbose: Verbose mode
    :type verbose: bool
    :param diff: Show the differences between the input files and the formatted ones
    :type diff: bool
    :param check_only: Checks that files have been autoformatted, defaults to False
    :type check_only: bool
    :return: Exit code
    :rtype: int
    """
    tic = time.perf_counter()

    # Only perform expensive import if this function is called
    import black

    if check_only:
        print("Checking black format...")
    else:
        print("Running black format...")

    # This ensures the following:
    #   * The defaults are changed without users of PyQA having to set them.
    #   * Users still have the option to override the default via `pyproject.toml`.
    for param in black.main.params:
        if param.name == "line_length":
            param.default = constants.MAX_LINE_LENGTH
            break

    # Fixes the problem where Click raises a RuntimeError on the selected encoding. Only needed for
    # older versions of click, and Python 3.6. Once we drop support for Python 3.6, we can remove
    # this.
    #   * On some environments ASCII encoding is selected by default (LANG=C) which leads
    #   * Click to prevent further execution until another locale is exported (a Unicode one).
    try:
        patch_click = black.patch_click  # type: ignore
    except AttributeError:
        # We can safely ignore this if our version of black doesn't have this function, as it means
        # we are not in a Python version that is affected.
        pass
    else:
        patch_click()

    argv = []
    if check_only:
        argv.append("--check")
    if verbose:
        argv.append("--verbose")
    if diff:
        argv.append("--diff")
    if sys.stdout.isatty():
        argv.append("--color")

    argv.append("--")  # Ensure that the following arguments are interpreted as paths.
    argv.extend(paths)

    exit_status: int = 0
    try:
        # This is not public API, so it may break with a future version of black.
        exit_status = black.main(argv)
    except SystemExit as exc:
        exit_status = int(exc.args[0])

    LOG.info("Exit status for black format is %d", exit_status)
    toc = time.perf_counter()
    print(f"Ran black format in {toc-tic:0.4f} seconds")
    return exit_status
