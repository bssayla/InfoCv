# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""
Python code quality assurance tool.

This package does not provide a public API for Python code. The `pyqa` application provides a
public command-line API.
"""
