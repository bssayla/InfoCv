# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Static checking on Python source code."""

import argparse
import time

from pyqa import duplication_checks
from pyqa.formatting import autoformatting_step_selector
from pyqa.utils.step_selector import SUBSTEP_SEPARATOR, StepSelector

checking_step_selector = StepSelector(
    [f"autoformat{SUBSTEP_SEPARATOR}{tool}" for tool in autoformatting_step_selector.steps]
    + ["linter", "spellcheck", "typecheck", "duplication"]
)


def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Add command-line arguments for static checks.

    :param subparsers: Subparsers to the main pyqa parser
    :type subparsers: argparse._SubParsersAction
    """
    parser_check = subparsers.add_parser("check", help="run static checks")
    checking_step_selector.add_parser_arguments(parser_check)
    parser_check.add_argument(
        "paths",
        nargs="+",
        help="paths to Python files or directories",
    )
    parser_check.add_argument(
        "--flake8-config",
        help=(
            "Path to flake8 config file. This option is only provided for compatibility and should "
            "be avoided. Instead, use a `setup.cfg` file in the working directory or one of the "
            "parent directories. Even better: use the default PyQA settings with no config file."
        ),
    )
    parser_check.add_argument(
        "--mypy-config",
        help=(
            "Path to mypy config file. This option is only provided for compatibility and should "
            "be avoided. Instead, use a `setup.cfg` file in the working directory or one of the "
            "parent directories. Even better: use the default PyQA settings with no config file."
        ),
    )
    parser_check.add_argument(
        "--flake8-args", type=str, help="Handle flake8 arguments", dest="flake8_arguments"
    )
    parser_check.add_argument(
        "--mypy-args", type=str, help="Handle mypy arguments", dest="mypy_arguments"
    )

    parser_check.set_defaults(run_subcommand=run)


def run(args: argparse.Namespace) -> int:
    """Run static quality checks.

    :param args: Arguments to run static checks
    :type args: argparse.Namespace
    :return: Exit code
    :rtype: int
    """

    # Only perform expensive import if this function is called
    from pyqa import formatting, stylecheck, typecheck
    from pyqa.__main__ import setup_parser

    exit_codes = [0]

    steps = checking_step_selector.selected_steps_set(args)

    autoformatting_tools = set(
        step.split(SUBSTEP_SEPARATOR)[1] for step in steps if step.startswith("autoformat")
    )
    if autoformatting_tools:
        # Run pyqa format with `--check-only` argument
        autoformat_exit_code = formatting.run(
            setup_parser().parse_args(
                ["format", "--check-only", *args.paths, "--steps", *autoformatting_tools]
            )
        )
        exit_codes.append(autoformat_exit_code)
    else:
        print("Skipped checking autoformatting")

    tic = time.perf_counter()
    if "linter" in steps:
        stylecheck_exit, _ = stylecheck.run(
            args.paths,
            config=args.flake8_config,
            html_report_directory=None,
            verbose=args.verbose,
            flake8_arguments=args.flake8_arguments,
            spellcheck=False,
        )
        exit_codes.append(stylecheck_exit)
    else:
        print("Skipped linting")

    if "spellcheck" in steps:
        print("Running flake8-spellcheck")
        stylecheck_exit, _ = stylecheck.run(
            args.paths,
            config=args.flake8_config,
            html_report_directory=None,
            verbose=args.verbose,
            flake8_arguments=args.flake8_arguments,
            quiet=True,
            linter=False,
        )
        exit_codes.append(stylecheck_exit)
    else:
        print("Skipped spelling checks")
    toc = time.perf_counter()
    if any(x == "linter" or x == "spellcheck" for x in steps):
        print(f"Ran flake8 in {toc - tic:0.4f} seconds")

    if "duplication" in steps:
        tic = time.perf_counter()
        duplication_exit = duplication_checks.run(args.paths)
        exit_codes.append(duplication_exit)

        toc = time.perf_counter()
        print(f"Ran pylint in {toc - tic:0.4f} seconds")
    else:
        print("Skipped duplication checks")

    if "typecheck" in steps:
        typecheck_exit_code = typecheck.run(
            args.paths,
            config=args.mypy_config,
            html_report_directory=None,
            verbose=args.verbose,
            mypy_arguments=args.mypy_arguments,
        )
        exit_codes.append(typecheck_exit_code)
    else:
        print("Skipped type checking")

    # Return the highest exit code to ensure that any problems are reported in the exit code.
    exit_status = max(exit_codes)
    return exit_status
