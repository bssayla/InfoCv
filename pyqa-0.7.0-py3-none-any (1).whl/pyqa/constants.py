# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Constants that are relevant in multiple contexts (e.g., autoformatting and style checking)."""

MAX_LINE_LENGTH = 100
SPELLING_CODES = ("SC100", "SC200")
LEVELS = ["low", "medium", "high"]
