# Copyright (C) 2021, 2024, Oracle and/or its affiliates.

"""Static type checking on Python source code."""

import contextlib
import logging
import os
import re
import shlex
import sys
import tempfile
import time
from string import Template
from typing import Iterable, List, Optional, TextIO, Union

import pkg_resources

from pyqa.reporting.report_entry import ReportEntry, ReportEntryStatus
from pyqa.utils.safe_run import log_exception_and_return

LOG = logging.getLogger(__name__)


@log_exception_and_return(1)
def run(
    paths: List[str],
    *,
    config: Optional[str] = None,
    html_report_directory: Optional[str] = None,
    verbose: bool = False,
    out_file: TextIO = sys.stdout,
    err_file: TextIO = sys.stderr,
    mypy_arguments: Optional[str] = None,
    **kwargs: Union[str, None],
) -> int:
    """
    Run mypy static type checks and return mypy exit status.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]
    :param html_report_directory: Directory path of the generated html report, defaults to None
    :type html_report_directory: Optional[str]
    :param verbose: Verbose mode, defaults to False
    :type verbose: bool
    :param out_file: Redirect mypy stdout to a file, defaults to sys.stdout
    :type out_file: TextIO
    :param err_file: Redirect mypy stderr to a file, defaults to sys.stderr
    :type err_file: TextIO
    :param mypy_arguments: Arguments to be passed directly to mypy
    :type mypy_arguments: Optional[str]
    :param kwargs: Additional keyword arguments passed to mypy

    :return: Exit code
    :rtype: int
    """
    tic = time.perf_counter()

    # Only perform expensive import if this function is called
    import mypy.main

    print("Running mypy...")

    argv = []
    if verbose:
        argv.append("--verbose")
    if config is not None:
        argv.extend(["--config-file", config])
    if mypy_arguments is not None:
        mypy_arg = shlex.split(mypy_arguments)
        for arg in mypy_arg:
            argv.append(arg)

    # Needs to happen outside the with block
    if html_report_directory is None:
        html_report_directory = os.getcwd()

    with cleaned_paths(paths, html_report_directory) as (paths, html_report_directory):
        # This needs to be inside the with block to make sure that the
        # report directory is cleaned
        argv.append(f"--html-report={html_report_directory}/mypy-precision")

        for k, v in kwargs.items():
            argv.append(f"--{k.replace('_', '-')}")
            if v is not None:
                argv.append(v)

        argv.append("--")  # Ensure that the following arguments are interpreted as paths.
        argv.extend(paths)

        exit_status = 0
        mypy_version = tuple(int(x) for x in mypy.main.__version__.split("+")[0].split("."))
        extra_kwargs = {} if mypy_version >= (0, 981) else {"script_path": None}
        try:
            # By using mypy.main.main, we get colorful output on the command line.
            # This is not public API, so it may break with a future version of mypy.
            mypy.main.main(
                stdout=out_file, stderr=err_file, args=argv, clean_exit=True, **extra_kwargs
            )
        except SystemExit as exc:
            exit_status = int(exc.args[0])

    LOG.info("Exit status for type checks is %s", exit_status)
    toc = time.perf_counter()
    print(f"Ran mypy in {toc-tic:0.4f} seconds")
    return exit_status


@log_exception_and_return(
    [
        ReportEntry(
            name="type precision",
            tool="mypy-precision",
            status=ReportEntryStatus.ERROR_ENCOUNTERED,
        ),
        ReportEntry(name="type checks", tool="mypy", status=ReportEntryStatus.ERROR_ENCOUNTERED),
    ]
)
def report_precision(
    paths: List[str],
    html_report_directory: Optional[str],
    mypy_arguments: Optional[str],
    verbose: bool = False,
    config: Optional[str] = None,
) -> Iterable[ReportEntry]:
    """
    Compute scores for typing.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param html_report_directory: Directory path of the generated html report
    :type html_report_directory: Optional[str]
    :param mypy_arguments: Mypy arguments handler
    :type mypy_arguments: Optional[str]
    :param verbose: Verbose mode, defaults to False
    :type verbose: bool
    :param config: Configuration file to use, defaults to None
    :type config: Optional[str]

    :raises RuntimeError: if typechecking returns with an unexpected exit code

    :return: Precision and typing results
    :rtype: Iterable[ReportEntry]
    """
    with tempfile.TemporaryDirectory() as tmpdirname:
        out = f"{tmpdirname}/out.txt"
        err = f"{tmpdirname}/err.txt"
        with open(out, "w") as out_file, open(err, "w") as err_file:
            exit_status = run(
                paths,
                mypy_arguments=mypy_arguments,
                config=config,
                html_report_directory=html_report_directory,
                verbose=verbose,
                lineprecision_report=tmpdirname,
                out_file=out_file,
                err_file=err_file,
                show_error_codes=None,
            )

            stdout_report = ""
            try:
                with open(f"{tmpdirname}/out.txt") as report:
                    stdout_report = report.read()
            except FileNotFoundError:
                pass

            stderr_report = None
            try:
                with open(f"{tmpdirname}/err.txt") as report:
                    stderr_report = report.read()
            except FileNotFoundError:
                pass

            os.makedirs(f"{html_report_directory}/mypy", exist_ok=True)
            with open(f"{html_report_directory}/mypy/index.html", "w") as html_report:
                html_report.write(mypy_html_format(stdout_report, stderr_report))

            if exit_status not in {0, 1}:
                raise RuntimeError("PyQA Typecheck run ended with an unexpected exit_status")

        with open(f"{tmpdirname}/lineprecision.txt") as report:
            # drop header and empty final line
            lines = report.read().split("\n")[2:-1]
            rows = [line.split() for line in lines]
            # transpose and drop the file names
            cols = [list(col) for col in zip(*rows)][1:]
            # convert all to int
            int_cols = [[int(el) for el in col] for col in cols]

            data = dict(
                zip(
                    ["Lines", "Precise", "Imprecise", "Any", "Empty", "Unanalyzed"],
                    int_cols,
                )
            )

            total_lines = sum(data["Lines"])
            empty_lines = sum(data["Empty"])
            bad_prec_lines = sum(data["Imprecise"]) + sum(data["Any"])

            # This mimics how mypy calculates the imprecision in the html report
            rel_prec_score = 100 * (1 - bad_prec_lines / total_lines)

        with open(f"{tmpdirname}/out.txt") as report:
            full_report = report.read()
            lines = full_report.split("\n")
            summary_line = lines[-2]
            match = re.match("Found ([0-9]+) errors in [0-9]+ files?", summary_line)

            type_errors = int(match[1]) if match else 0
            rel_type_score = 100 * (1 - type_errors / (total_lines - empty_lines))

        type_precision_report_entry = ReportEntry(
            name="type precision",
            tool="mypy-precision",
            score=rel_prec_score,
            issues_count=bad_prec_lines,
        )
        type_check_report_entry = ReportEntry(
            name="type checks",
            tool="mypy",
            score=rel_type_score,
            issues_count=type_errors,
        )
        return type_precision_report_entry, type_check_report_entry


def mypy_html_format(report: str, err: Optional[str] = None) -> str:
    """Generate report html index file summarizing the scores collected.

    :param report: Stdout from 'mypy' to report
    :type report: str
    :param err: Stderr from 'mypy' to report, defaults to None
    :type err: Optional[str]
    :return: Template string
    :rtype: str
    """

    resource_path: str = os.path.join("templates", "mypy_report.html")
    bytes_data: bytes = pkg_resources.resource_string("pyqa.reporting", resource_path)
    html_template = Template(str(bytes_data, "utf-8"))

    # Emphasize strings
    report = re.sub(r'(".*?")', r'<span class="str">\1</span>', report)
    # Type of message: so far only "note" or "error" have styling
    report = re.sub("(.*:[0-9]+: )([a-z]+):", r'\1<span class="\2">\2:</span>', report)
    # Error codes
    report = re.sub(r"  (\[[a-zA-Z\-]+\])", r'  <span class="err-code">\1</span>', report)
    # Highlight summary line
    report = re.sub(
        r"(Found [0-9]+ errors in [0-9]+ files?.*)", r'<span class="error">\1</span>', report
    )
    report = report.replace("\n", "<br/>\n")

    if err:
        err_report = err.replace("\n", "<br/>\n")
    else:
        err_report = ""

    return html_template.substitute(
        report_output=report,
        error_output=err_report,
        display_err="block" if err else "none",
    )


@contextlib.contextmanager
def cleaned_paths(paths: List[str], *args):
    """Clean the paths to work around a mypy package bug.

    The mypy package bug causes any directory that is being
    searched to be skipped if the relative path from the current
    working directory to that directory starts with "..".

    This contextmanager "cleans" the paths by changing the current
    working directory to the largest common path prefix and
    running mypy from there using the absolute paths of all the
    paths.

    If optional args are passed, they are also cleaned and yielded
    in their original order.

    :param paths: Paths to python files or directories
    :type paths: List[str]
    :param args: Additional arguments that will be passed to the function
    :yield: Cleaned paths and cleaned args if passed
    :rtype: Generator
    """
    # The "cleaned" paths are just the absolute paths
    cleaned_paths = [os.path.abspath(path) for path in paths]
    current_directory = os.path.abspath(os.getcwd())

    # Find the largest common base path shared between the current
    # working directory and all of these paths
    all_paths = cleaned_paths + [os.path.abspath(os.getcwd())]
    base_path = os.path.commonpath(all_paths)

    # Clean some extra paths as well
    cleaned_args = [os.path.abspath(arg) for arg in args]

    # Change to the base directory
    os.chdir(base_path)
    try:
        if len(cleaned_args) > 0:
            yield tuple([cleaned_paths] + cleaned_args)
        else:
            yield cleaned_paths
    finally:
        # Change back to the original directory
        os.chdir(current_directory)
